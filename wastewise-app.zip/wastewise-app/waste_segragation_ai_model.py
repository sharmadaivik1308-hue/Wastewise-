import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras import layers, models
from PIL import Image
import os

IMG_SIZE = 224
BATCH_SIZE = 32
CLASSES = ['cardboard', 'glass', 'metal', 'paper', 'plastic', 'trash']

# ─── TRAIN AND SAVE MODEL ───────────────────────────────────────
def train_model():
    datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

    train_data = datagen.flow_from_directory(
        "dataset/dataset-resized",
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode="categorical",
        subset="training"
    )

    val_data = datagen.flow_from_directory(
        "dataset/dataset-resized",
        target_size=(IMG_SIZE, IMG_SIZE),
        batch_size=BATCH_SIZE,
        class_mode="categorical",
        subset="validation"
    )

    base_model = MobileNetV2(weights="imagenet", include_top=False, input_shape=(224, 224, 3))
    base_model.trainable = False

    x = base_model.output
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(128, activation="relu")(x)
    output = layers.Dense(6, activation="softmax")(x)

    model = models.Model(inputs=base_model.input, outputs=output)
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])

    print("🚀 Training started...")
    model.fit(train_data, validation_data=val_data, epochs=10)

    model.save("waste_model.h5")
    print("✅ Model saved as waste_model.h5")

# ─── LOAD MODEL ONCE ────────────────────────────────────────────
model = None

def load_model():
    global model
    if model is None:
        if not os.path.exists("waste_model.h5"):
            print("⚠️ Model not found! Training now...")
            train_model()
        model = tf.keras.models.load_model("waste_model.h5")
        print("✅ Model loaded!")
    return model

# ─── PREDICT FUNCTION (used by api.py) ──────────────────────────
def predict_waste(image: Image.Image):
    m = load_model()

    img = image.resize((IMG_SIZE, IMG_SIZE))
    img_array = np.array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    prediction = m.predict(img_array)
    index = np.argmax(prediction)
    confidence = float(np.max(prediction))

    return CLASSES[index], confidence