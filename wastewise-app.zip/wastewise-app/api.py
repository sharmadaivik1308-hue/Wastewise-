from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
from PIL import Image
import io
import base64

# Import your existing model
from waste_segragation_ai_model import predict_waste

app = Flask(__name__)
CORS(app)  # Allow Next.js to call this

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json

    # Decode base64 image from frontend
    image_data = base64.b64decode(data['image'])
    image = Image.open(io.BytesIO(image_data)).convert('RGB')

    # Run your model — now returns (waste_type, confidence)
    prediction, confidence = predict_waste(image)

    # Map waste type to bin color
    bin_map = {
        "plastic":   {"bin": "Blue Bin",   "color": "#2563eb", "emoji": "🔵"},
        "paper":     {"bin": "Blue Bin",   "color": "#2563eb", "emoji": "🔵"},
        "metal":     {"bin": "Blue Bin",   "color": "#2563eb", "emoji": "🔵"},
        "cardboard": {"bin": "Blue Bin",   "color": "#2563eb", "emoji": "🔵"},
        "organic":   {"bin": "Green Bin",  "color": "#16a34a", "emoji": "🟢"},
        "food":      {"bin": "Green Bin",  "color": "#16a34a", "emoji": "🟢"},
        "hazardous": {"bin": "Red Bin",    "color": "#dc2626", "emoji": "🔴"},
        "e-waste":   {"bin": "Yellow Bin", "color": "#ca8a04", "emoji": "🟡"},
        "glass":     {"bin": "White Bin",  "color": "#9ca3af", "emoji": "⚪"},
        "trash":     {"bin": "Black Bin",  "color": "#1f2937", "emoji": "🗑️"},
    }

    result = bin_map.get(prediction.lower(), {
        "bin": "General Waste", "color": "#6b7280", "emoji": "🗑️"
    })

    return jsonify({
        "waste_type": prediction,
        "bin": result["bin"],
        "color": result["color"],
        "emoji": result["emoji"],
        "confidence": round(confidence * 100, 2)  # e.g. 95.43
    })

if __name__ == '__main__':
    app.run(port=5000, debug=True)